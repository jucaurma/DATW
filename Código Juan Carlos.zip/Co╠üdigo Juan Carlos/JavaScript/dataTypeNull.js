// Definir una variable inicializada con null
let miVariable = null;
// Realizar una verificación de null
if (miVariable === null) {
console.log("La variable está inicializada como null.");
} else {
console.log("La variable no está inicializada como null.");
}