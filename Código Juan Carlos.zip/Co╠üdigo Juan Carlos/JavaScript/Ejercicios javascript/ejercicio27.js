// Escribe una función que tome un array y un
// elemento como entrada, y devuelva el índice del primer elemento encontrado en el
// array. Si el elemento no está presente, devuelve -1

miarray = [1,2,3,4,5,6];
console.log(miarray.indexOf(9));