// Definir números enteros y de punto flotante
let entero = 10;
let flotante = 3.14;
// Realizar operaciones aritméticas
let suma = entero + flotante; // Suma
let resta = entero - flotante; // Resta
let multiplicacion = entero * flotante; // Multiplicación
let division = entero / flotante; // División
// Imprimir los resultados
console.log("Suma:", suma); // Imprimirá: Suma: 13.14
console.log("Resta:", resta); // Imprimirá: Resta: 6.86
console.log("Multiplicación:", multiplicacion); // Imprimirá: Multiplicación: 31.4
console.log("División:", division); // Imprimirá: División: 3.1847133757961785