// Definir variables booleanas
let esVerdadero = true;
let esFalso = false;
// Realizar operaciones lógicas
let resultadoY = esVerdadero && esFalso; // AND lógico
let resultadoO = esVerdadero || esFalso; // OR lógico
let resultadoNegacion = !esVerdadero; // Negación lógica
// Imprimir los resultados
console.log("Resultado AND:", resultadoY); // Imprimirá: Resultado AND: false
console.log("Resultado OR:", resultadoO); // Imprimirá: Resultado OR: true
console.log("Negación:", resultadoNegacion); // Imprimirá: Negación: false