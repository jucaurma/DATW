// Definir cadenas de texto
let saludo = '¡Hola, mundo!';
let nombre = "Juan";
// Concatenar cadenas
let mensaje = saludo + ' Mi nombre es ' + nombre;
// Imprimir el mensaje
console.log(mensaje); // Imprimirá: ¡Hola, mundo! Mi nombre es Juan