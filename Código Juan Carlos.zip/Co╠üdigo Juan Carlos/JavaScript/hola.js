console.log("Hola Mundo");
var miNombre = "Juan Carlos";
console.log(miNombre);
console.log(miNombre==="Juan Carlos");
