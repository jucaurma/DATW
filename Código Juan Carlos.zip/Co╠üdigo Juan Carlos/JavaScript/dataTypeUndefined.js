// Definir una variable sin asignarle un valor
let variableIndefinida;
// Imprimir el valor de la variable
console.log("Valor de la variable:", variableIndefinida); // Imprimirá: Valor de la variable: undefined
// Verificar si la variable está definida
if (typeof variableIndefinida === 'undefined') {
console.log("La variable está indefinida.");
} else {
console.log("La variable está definida.");
}