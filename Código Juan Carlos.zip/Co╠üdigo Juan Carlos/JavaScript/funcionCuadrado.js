function cuadrado(num){
    return num*num;
    }

let num =17237239756;
resultado = cuadrado(num);
console.log("El cuadrado de " + num + " es: " + resultado);