function isEven(number) {
    return number % 2 === 0;
}
// Example usage:
var myNumber = 9;
if (isEven(myNumber)) {
    console.log(myNumber + " is even.");
} else {
    console.log(myNumber + " is odd.");
}